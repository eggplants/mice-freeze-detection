# mouse behavior tracking

how to build (for windiws)
```bash
pyinstaller tracking.py --onefile -i icon.ico
```

original code written by natsukacha (https://github.com/natsukacha)  
icon from https://icon-icons.com/icon/testing-mouse-sciencie-scientific/53002